from django import forms
from django.contrib.auth.forms import UserCreationForm, UsernameField, AuthenticationForm, PasswordChangeForm, \
    PasswordResetForm, SetPasswordForm
from django.contrib.auth.models import User

from .models import Customer, Product

'''
This is a Django form class for customer registration.
It extends the UserCreationForm, which is a built-in form for user registration with username and password.
'''


class CustomerRegistrationForm(UserCreationForm):
    ROLES = (
        ('customer', 'Customer'),
        ('seller', 'Seller'),
    )
    role = forms.ChoiceField(choices=ROLES, label='Role', widget=forms.Select(attrs={'class': 'form-control'}))

    password1 = forms.CharField(label='password', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    password2 = forms.CharField(label='confirm password', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    email = forms.CharField(required='True', widget=forms.EmailInput(attrs={'class': 'form-control'}))

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2','role']
        labels = {'email': 'Email'}
        widgets = {'username': forms.TextInput(attrs={'class': 'form-control'})}

'''
This is a Django form class for user login.
It extends the AuthenticationForm, which is a built-in form for user authentication.
'''
class LoginForm(AuthenticationForm):
    username = UsernameField(widget=forms.TextInput(attrs={'autofocus': True, 'class': 'form-control'}))
    password = forms.CharField(label=("Password"), strip=False, widget=forms.PasswordInput(attrs={'autocomplete': 'current-password', 'autofocus': True, 'class': 'form-control'}))


'''
This is a Django form class for changing customer passwords.
It extends the PasswordChangeForm, which is a built-in form for changing user passwords.
'''
class ChangePassword(PasswordChangeForm):
    old_password = forms.CharField(label=("old password"), strip=False, widget=forms.PasswordInput
    (attrs={'autocomplete': 'currrent password', 'autofocus': True, 'class': 'form-control'}))
    new_password1 = forms.CharField(label=("new password"), strip=False, widget=forms.PasswordInput
    (attrs={'autocomplete': 'currrent password', 'autofocus': True, 'class': 'form-control'}))
    new_password2 = forms.CharField(label=("confirm new password"), strip=False, widget=forms.PasswordInput
    (attrs={'autocomplete': 'currrent password', 'autofocus': True, 'class': 'form-control'}))


'''
This is a Django form class for resetting passwords.
It extends the PasswordResetForm, which is a built-in form for resetting user passwords.
'''
class MyPasswordResetForm(PasswordResetForm):
    email = forms.EmailField(label=("Email"),max_length=254,
                             widget=forms.EmailInput(attrs={'autocomplete':'email','class':'form-control'}))


'''
This is a Django form class for confirming the password reset.
It extends the SetPasswordForm, which is a built-in form for setting a new user password after a password reset request.
'''
class PasswordResetConfirmForm(SetPasswordForm):
     new_password1 = forms.CharField(label=("new password"),strip=False,widget=forms.PasswordInput
    (attrs={'autocomplete':'currrent password' ,'autofocus':True,'class':'form-control' }))
     new_password2 = forms.CharField(label=("confirm new password"),strip=False,widget=forms.PasswordInput
    (attrs={'autocomplete':'currrent password' ,'autofocus':True,'class':'form-control' }))



'''
This is a Django ModelForm class for updating customer profiles.
It is associated with the Customer model.
'''
class CutomerProfileForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['id','name','locality','city','state','zipcode']
        widgets = {'name':forms.TextInput(attrs={'class':'form-control'}),
                   'locality':forms.TextInput(attrs={'class':'form-control'}),
                   'city':forms.TextInput(attrs={'class':'form-control'}),
                   'state':forms.Select(attrs={'class':'form-control'}),
                   'zipcode':forms.NumberInput(attrs={'class':'form-control'})}


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['title', 'selling_price', 'discounted_price', 'description', 'brand', 'category', 'product_image']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control form-control-md', 'placeholder': 'Product Title'}),
            'selling_price': forms.NumberInput(attrs={'class': 'form-control form-control-md', 'placeholder': 'Selling Price'}),
            'discounted_price': forms.NumberInput(attrs={'class': 'form-control form-control-md', 'placeholder': 'Discounted Price'}),
            'description': forms.Textarea(attrs={'class': 'form-control form-control-sm', 'placeholder': 'Product Description','rows':4}),
            'brand': forms.TextInput(attrs={'class': 'form-control form-control-md','placeholder': 'Product Brand'}),
            'category': forms.Select(attrs={'class': 'form-control form-control-md'}),
            'product_image': forms.FileInput(attrs={'class': 'form-control-file'}),
        }
        labels = {
            'title': False,
            'selling_price': False,
            'discounted_price': False,
            'description': False,
            'brand': False,
            'product_image': False,
        }


