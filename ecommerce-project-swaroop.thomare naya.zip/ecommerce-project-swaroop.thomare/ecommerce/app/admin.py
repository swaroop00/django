from django.contrib import admin
from .models import Customer, Product, Cart, OrderPlaced

'''
This code registers the Customer model with the Django admin site ,
and provides a custom ModelAdmin configuration for it.
'''


@admin.register(Customer)
class CustomerModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'name', 'locality', 'city', 'zipcode', 'state', 'role']


'''
This code registers the Product model with the Django admin site ,
and provides a custom ModelAdmin configuration for it.
'''


@admin.register(Product)
class ProductModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'selling_price', 'discounted_price',
                    'description', 'brand', 'category', 'product_image']


'''
This code registers the Cart model with the Django admin site and provides ,
a custom ModelAdmin configuration for it.
'''


@admin.register(Cart)
class CartModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'product', 'quantity']


'''
This code registers the OrderPlaced model with the Django admin site and 
provides a custom ModelAdmin configuration for it.
'''


@admin.register(OrderPlaced)
class OrderPlacedModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'product',
                    'quantity', 'ordered_date', 'status']




